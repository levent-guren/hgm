package hgm.gov.dao;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import hgm.gov.beans.Personel;
import hgm.gov.repository.PersonelRepository;

@Named
public class PersonelDAO {
	@Inject
	private PersonelRepository personelRepository;

	public List<Personel> getPersoneller() {
		return personelRepository.findAll();
	}
}
