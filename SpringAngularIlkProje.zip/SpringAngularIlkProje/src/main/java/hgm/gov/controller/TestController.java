package hgm.gov.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import hgm.gov.beans.Personel;
import hgm.gov.service.PersonelService;

@RestController
public class TestController {
	@Inject
	private PersonelService personelService;

	@GetMapping(value = "/deneme", produces = { MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE })
	public Personel test() {
		Personel p = new Personel(1, "Ali", "Kaval");
		return p;
	}

	@GetMapping("/personel")
	public List<Personel> getPersoneller() {
		return personelService.getPersoneller();
	}
}
