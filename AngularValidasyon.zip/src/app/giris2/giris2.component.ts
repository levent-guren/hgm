import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { selectValidator } from '../validators/selectValidator';

@Component({
  selector: 'app-giris2',
  templateUrl: './giris2.component.html',
  styleUrls: ['./giris2.component.scss']
})
export class Giris2Component implements OnInit {
  girisForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.girisForm = this.fb.group({
      adi: [''],
      eposta: '',
      eposta2: '',
      programlamaDili: ['0', selectValidator ]
    }, { validators: } ]);
  }
  get adi() {
    return this.girisForm.get('adi');
  }
  get eposta() {
    return this.girisForm.get('eposta');
  }
  get eposta2() {
    return this.girisForm.get('eposta2');
  }
  get programlamaDili() {
    return this.girisForm.get('programlamaDili');
  }

}
