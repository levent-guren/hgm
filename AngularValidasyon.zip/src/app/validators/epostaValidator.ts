import { AbstractControl } from "@angular/forms";

export function epostaValidator(form: AbstractControl): { [hata: string]: any } | null {
  form.get('eposta2')?.setErrors(null);
  if (form.get('eposta')?.value &&
    form.get('eposta')?.value !== form.get('eposta2')?.value) {
    // iki posta içeriği eşit değil
    // eposta2 alanına özel hata oluştuluyor.
    form.get('eposta2').setErrors({ "eposta2": "E posta ile aynı değil" });
    // form bazında genel bir hata oluştuluyor.
    return { "hata": "Eposta alanları eşit değiller"};
  }
  return null;
}
