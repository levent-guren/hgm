package hgm.gov.business;

import org.springframework.stereotype.Service;

@Service
public class TestBusiness {
	public void deneme() {
		System.out.println("TestBusiness.deneme");
	}
}
