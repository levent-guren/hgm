package model;

import lombok.Data;

@Data
public class PersonelAdresModel {
	private int id;
	private String adres;
}
