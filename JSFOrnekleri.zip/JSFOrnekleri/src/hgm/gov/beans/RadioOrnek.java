package hgm.gov.beans;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import lombok.Data;

@Data
@ManagedBean
@SessionScoped
public class RadioOrnek {
	private String deger;

	public void oku() {
	}

}
