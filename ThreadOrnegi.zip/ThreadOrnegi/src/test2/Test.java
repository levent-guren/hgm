package test2;

public class Test {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		Thread m = new Thread(myThread);
		Thread m2 = new Thread(myThread);
		m.start();
		m2.start();
		System.out.println("Program bitti.");
	}

}
