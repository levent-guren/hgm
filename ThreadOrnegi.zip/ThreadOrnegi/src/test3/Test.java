package test3;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Test {

	public static void main(String[] args) {
		MyThread myThread = new MyThread();
		ExecutorService executorService = Executors.newFixedThreadPool(2);

		executorService.execute(myThread);
		executorService.execute(myThread);

		System.out.println("Program bitti.");
	}

}
