package hgm.gov.dao;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;

import hgm.gov.entities.Rapor;
import hgm.gov.repository.RaporRepository;

@Named
public class RaporDAO {
	@Inject
	private RaporRepository raporRepository;

	public Optional<Rapor> getRapor(int id) {
		return raporRepository.findById(id);
	}

	public List<Rapor> getRaporlar() {
		return raporRepository.findAll();
	}

	public Rapor raporGuncelle(Rapor rapor) {
		return raporRepository.save(rapor);
	}

}
