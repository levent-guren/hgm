package hgm.gov.util;

public class Sabitler {
	public static final int YETKI_PERSONEL_LISTELEME = 1;
	public static final int YETKI_PERSONEL_YARATMA = 2;

	private Sabitler() {
	}
}
