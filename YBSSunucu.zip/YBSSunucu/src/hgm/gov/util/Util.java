package hgm.gov.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.http.HttpSession;

import org.springframework.format.datetime.standard.DateTimeFormatterFactory;

import com.google.gson.JsonObject;

import hgm.gov.entities.PersonelYetki;

public class Util {
	private static PasswordAuthentication passwordAuthentication = new PasswordAuthentication();
	private static ExecutorService executorService = Executors.newFixedThreadPool(2);
	private static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	private static DateTimeFormatter dateTimeFormatter = new DateTimeFormatterFactory("dd.MM.yyyy HH:mm").createDateTimeFormatter();
	private static ZoneId turkeyZoneId = ZoneId.of("+03:00");

	// instance yaratilmasini engeller
	private Util() {
	}

	public static Date getDateFromString(String tarih) {
		Date result = null;
		try {
			result = dateFormat.parse(tarih);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return result;
	}

	public static String getFormattedDate(Instant date) {
		return date.atZone(turkeyZoneId).format(dateTimeFormatter);
	}

	public static String getFormattedDate(LocalDateTime time) {
		return getFormattedDate(time.atZone(turkeyZoneId).toInstant());
	}

	public static String getFormattedDate(Date date) {
		return getFormattedDate(date.toInstant());
	}

	public static ExecutorService getExecutorService() {
		return executorService;
	}

	public static PasswordAuthentication getPasswordAuthentication() {
		return passwordAuthentication;
	}

	@SuppressWarnings("unchecked")
	public static boolean yetkiVarmi(HttpSession session, int yetkiId) {
		List<PersonelYetki> personelYetkiler = (List<PersonelYetki>) session.getAttribute("yetkiler");
		if (personelYetkiler != null) {
			for (PersonelYetki personelYetki : personelYetkiler) {
				if (personelYetki.getYetki().getId() == yetkiId) {
					return true;
				}
			}
		}
		return false;
	}

	public static String cevapBasarili() {
		JsonObject sonuc = new JsonObject();
		sonuc.addProperty("sonuc", "basarili");
		return sonuc.toString();
	}

	public static void main(String[] args) {
		System.out.println(passwordAuthentication.hash("123".toCharArray()));
	}
}
