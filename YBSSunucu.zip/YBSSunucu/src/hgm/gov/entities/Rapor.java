package hgm.gov.entities;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

/**
 * The persistent class for the personel database table.
 * 
 */
@Data
@Entity
public class Rapor implements Serializable {
	private static final long serialVersionUID = 7866557269218362887L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String adi;

	@Column(name = "personel_id")
	private int personelId;

	private LocalDateTime tarih;
	private byte[] rapor;

}