package hgm.gov.service;

import javax.inject.Named;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
@Named
public class LogService {
	@Before("execution(* hgm.gov.dao.*.*(..)) && target(dao) && args(param)")
	public void log(Object param, Object dao) {
		System.out.println("Log cagirildi.");
		System.out.println("Class:" + dao.getClass().getName());
		System.out.println("params:");
		System.out.println(param);
	}
}
