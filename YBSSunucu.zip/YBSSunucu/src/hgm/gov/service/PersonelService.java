package hgm.gov.service;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import hgm.gov.dao.PersonelDAO;
import hgm.gov.entities.Personel;
import hgm.gov.util.Util;

@Named
public class PersonelService {
	@Inject
	private PersonelDAO personelDAO;

	public boolean girisYap(String tcNo, String sifre) {
		Optional<Personel> personel = personelDAO.getPersonel(tcNo);
		if (personel.isPresent()) {
			if (Util.getPasswordAuthentication().authenticate(sifre.toCharArray(), personel.get().getSifre())) {
				return true;
			}
		}
		return false;
	}

	public List<Personel> getPersonelListesi() {
		return personelDAO.getPersoneller();
	}

	public Personel getPersonel(int id) {
		Optional<Personel> personel = personelDAO.getPersonel(id);
		if (personel.isPresent()) {
			return personel.get();
		}
		return null;
	}

	@Transactional
	public void personelGuncelle(int id, Personel personel) {
		Personel personelDB = getPersonel(id);
		personelDB.setAdi(personel.getAdi());
		personelDB.setSoyadi(personel.getSoyadi());
		personelDB.setTcno(personel.getTcno());
		personelDB.setEvKoordinatEnlem(personel.getEvKoordinatEnlem());
		personelDB.setEvKoordinatBoylam(personel.getEvKoordinatBoylam());
		personelDAO.personelGuncelle(personelDB);
	}
}
