package hgm.gov.service;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Optional;

import javax.imageio.ImageIO;
import javax.inject.Inject;
import javax.inject.Named;
import javax.transaction.Transactional;

import hgm.gov.dao.PersonelDAO;
import hgm.gov.entities.Personel;
import hgm.gov.util.Util;

@Named
public class PersonelService {
	@Inject
	private PersonelDAO personelDAO;

	public boolean girisYap(String tcNo, String sifre) {
		Optional<Personel> personel = personelDAO.getPersonel(tcNo);
		if (personel.isPresent()) {
			if (Util.getPasswordAuthentication().authenticate(sifre.toCharArray(), personel.get().getSifre())) {
				return true;
			}
		}
		return false;
	}

	public List<Personel> getPersonelListesi() {
		return personelDAO.getPersoneller();
	}

	public Personel getPersonel(int id) {
		Optional<Personel> personel = personelDAO.getPersonel(id);
		if (personel.isPresent()) {
			return personel.get();
		}
		return null;
	}

	@Transactional
	public void personelGuncelle(int id, Personel personel) {
		Personel personelDB = getPersonel(id);
		personelDB.setAdi(personel.getAdi());
		personelDB.setSoyadi(personel.getSoyadi());
		personelDB.setTcno(personel.getTcno());
		personelDB.setEvKoordinatEnlem(personel.getEvKoordinatEnlem());
		personelDB.setEvKoordinatBoylam(personel.getEvKoordinatBoylam());
		if (personel.getResim() != null) {
			personelDB.setResim(resize(personel.getResim()));
		}
		personelDAO.personelGuncelle(personelDB);
	}

	private byte[] resize(byte[] resim) {
		try {
			// byte[] 'den resim(BufferedImage) olu�turuluyor.
			InputStream inputStream = new ByteArrayInputStream(resim);
			BufferedImage image = ImageIO.read(inputStream);

			// resim boyutland�r�l�yor
			Image i = image.getScaledInstance(100, 100, Image.SCALE_SMOOTH);

			// Image tipindeki resim BufferedImage tipine �evriliyor.
			BufferedImage buffered = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
			buffered.getGraphics().drawImage(i, 0, 0, null);

			// BufferImage tipindeki resim byte[]'e d�n��t�r�l�yor.
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(buffered, "jpg", baos);
			return baos.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
