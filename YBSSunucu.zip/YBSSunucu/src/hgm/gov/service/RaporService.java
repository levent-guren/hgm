package hgm.gov.service;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;

import hgm.gov.dao.RaporDAO;
import hgm.gov.entities.Rapor;

@Named
public class RaporService {
	@Inject
	private RaporDAO raporDAO;

	public List<Rapor> getRaporlar() {
		return raporDAO.getRaporlar();
	}

	public Rapor getRapor(int id) {
		Optional<Rapor> rapor = raporDAO.getRapor(id);
		if (rapor.isPresent()) {
			return rapor.get();
		}
		return null;
	}

	public void raporYarat(String adi) {
		Thread t = new Thread(() -> {
			// rapor burada olu�turulacak.
		});
		t.start();
	}

}
