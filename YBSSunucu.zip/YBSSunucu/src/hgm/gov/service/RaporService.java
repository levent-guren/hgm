package hgm.gov.service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.sql.DataSource;

import hgm.gov.dao.RaporDAO;
import hgm.gov.entities.Rapor;
import hgm.gov.util.Util;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
import net.sf.jasperreports.export.SimplePdfReportConfiguration;

@Named
public class RaporService {
	@Inject
	private DataSource dataSource;

	@Inject
	private RaporDAO raporDAO;

	public List<Rapor> getRaporlar() {
		return raporDAO.getRaporlar();
	}

	public Rapor getRapor(int id) {
		Optional<Rapor> rapor = raporDAO.getRapor(id);
		if (rapor.isPresent()) {
			return rapor.get();
		}
		return null;
	}

	public void raporYarat(int personelId, String adi) {
		Util.getExecutorService().execute(() -> {
			// rapor burada olu�turulacak.
			raporOlustur(personelId, adi);
		});
	}

	private void raporOlustur(int personelId, String adi) {
		try {
			JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile("c:/java/rapor/" + adi + ".jasper");

			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, dataSource.getConnection());
			JRPdfExporter exporter = new JRPdfExporter();
			exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
			ByteArrayOutputStream s = new ByteArrayOutputStream();
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(s));

			SimplePdfReportConfiguration reportConfig = new SimplePdfReportConfiguration();
			reportConfig.setSizePageToContent(true);
			reportConfig.setForceLineBreakPolicy(false);

			SimplePdfExporterConfiguration exportConfig = new SimplePdfExporterConfiguration();
			exportConfig.setMetadataAuthor("Levent GUREN");
			exportConfig.setEncrypted(true);
			exportConfig.setAllowedPermissionsHint("PRINTING");

			exporter.setConfiguration(reportConfig);
			exporter.setConfiguration(exportConfig);

			exporter.exportReport();
			byte[] raporIcerik = s.toByteArray();

			Rapor rapor = new Rapor();
			rapor.setPersonelId(personelId);
			rapor.setTarih(LocalDateTime.now());
			rapor.setRapor(raporIcerik);
			rapor.setAdi(adi);

			raporDAO.raporKaydet(rapor);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
