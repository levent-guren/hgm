package hgm.gov.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import hgm.gov.entities.Rapor;

public interface RaporRepository extends JpaRepository<Rapor, Integer> {

}
