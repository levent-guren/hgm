package hgm.gov.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

@WebFilter(urlPatterns = "/*")
public class LoginFilter implements Filter {
	public void destroy() {
	}

	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		String url = request.getServletPath();
		if (url.equals("/giris")) {
			// giri� yap�lmas�na her zaman izin ver.
			chain.doFilter(request, response);
		} else if (request.getSession().getAttribute("login") != null) {
			// login olunmu� ise izin ver.
			chain.doFilter(request, response);
		} else {
			// login olunmadan giris d���ndaki bir yere istekte bulunulmu�. Engelliyouz.
			JSONObject hata = new JSONObject();
			hata.put("sonuc", "Once giris yapmalisiniz");
			response.getWriter().print(hata.toString());
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
