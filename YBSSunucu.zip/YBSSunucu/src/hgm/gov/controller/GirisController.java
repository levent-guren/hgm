package hgm.gov.controller;

import java.util.Base64;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import hgm.gov.entities.Personel;
import hgm.gov.service.PersonelService;

@RestController
public class GirisController {
	@Inject
	private PersonelService personelService;

	@PostMapping("/giris")
	public String giris(@RequestBody String data, HttpSession session) {
		JsonObject jsonData = JsonParser.parseString(data).getAsJsonObject();
		String tcNo = jsonData.get("tcNo").getAsString();
		String sifre = jsonData.get("sifre").getAsString();

		JsonObject sonuc = new JsonObject();
		Personel personel = personelService.girisYap(tcNo, sifre);
		if (personel != null) {
			// tcno/sifre do�ru.
			sonuc.addProperty("sonuc", true);
			sonuc.addProperty("adi", personel.getAdi());
			sonuc.addProperty("soyadi", personel.getSoyadi());
			sonuc.addProperty("birlikId", personel.getBirlikId());
			sonuc.addProperty("resim", new String(Base64.getEncoder().encode(personel.getResim())));
			session.setAttribute("login", personel);
		} else {
			sonuc.addProperty("sonuc", false);
		}
		return sonuc.toString();
	}

}
