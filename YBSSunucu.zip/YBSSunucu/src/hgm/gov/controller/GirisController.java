package hgm.gov.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import hgm.gov.entities.Personel;
import hgm.gov.service.PersonelService;
import hgm.gov.util.Util;

@RestController
public class GirisController {
	@Inject
	private PersonelService personelService;

	@PostMapping("/giris")
	public String giris(@RequestBody String data) {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		HttpSession session = attr.getRequest().getSession(true);

		JsonObject jsonData = JsonParser.parseString(data).getAsJsonObject();
		String tcNo = jsonData.get("tcNo").getAsString();
		String sifre = jsonData.get("sifre").getAsString();

		JsonObject sonuc = new JsonObject();
		Personel personel = personelService.girisYap(tcNo, sifre);
		if (personel != null) {
			// tcno/sifre do�ru.
			sonuc.addProperty("sonuc", true);
			session.setAttribute("login", personel);
			Util.personel = personel;
		} else {
			sonuc.addProperty("sonuc", false);
		}
		return sonuc.toString();
	}

}
