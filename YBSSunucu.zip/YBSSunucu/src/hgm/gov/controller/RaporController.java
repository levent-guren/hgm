package hgm.gov.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import hgm.gov.entities.Personel;
import hgm.gov.entities.Rapor;
import hgm.gov.service.RaporService;
import hgm.gov.util.Util;

@RestController
@RequestMapping("/rapor")
public class RaporController {
	@Inject
	private RaporService raporService;

	@GetMapping("/liste")
	public String liste(HttpSession session) {
		// int personelId = ((Personel) session.getAttribute("login")).getId();
		int personelId = Util.personel.getId();
		JsonArray sonuc = new JsonArray();
		raporService.getRaporlar().parallelStream().filter(r -> r.getPersonelId() == personelId).forEach(r -> {
			JsonObject raporJson = new JsonObject();
			raporJson.addProperty("id", r.getId());
			raporJson.addProperty("adi", r.getAdi());
			raporJson.addProperty("personelId", r.getPersonelId());
			raporJson.addProperty("tarih", Util.getFormattedDate(r.getTarih()));
			sonuc.add(raporJson);
		});
		return sonuc.toString();
	}

	@GetMapping(value = "/detay/{id}", produces = { MediaType.APPLICATION_PDF_VALUE })
	public byte[] detay(@PathVariable int id) {
		Rapor rapor = raporService.getRapor(id);
		return rapor.getRapor();
	}

	@PutMapping(value = "/olustur")
	public String raporOlustur(@RequestBody String requrestBody) {
		JsonObject requestJSON = JsonParser.parseString(requrestBody).getAsJsonObject();
		String raporAdi = requestJSON.get("raporAdi").getAsString();
		// Personel personel = (Personel) session.getAttribute("login");
		Personel personel = Util.personel;
		raporService.raporYarat(personel.getId(), raporAdi);
		return Util.cevapBasarili();
	}

}
