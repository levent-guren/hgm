package hgm.gov.controller;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;

import hgm.gov.service.RaporService;
import hgm.gov.util.Util;

@RestController
@RequestMapping("/rapor")
public class RaporController {
	@Inject
	private RaporService raporService;

	@GetMapping("/liste")
	public String liste() {
		JsonArray sonuc = new JsonArray();
		return sonuc.toString();
	}

	@GetMapping("/detay/{id}")
	public String detay(@PathVariable int id) {

		return "";
	}

	@PutMapping(value = "/olustur/{adi}")
	public String raporOlustur(@PathVariable String adi) {
		raporService.raporYarat(adi);
		return Util.cevapBasarili();
	}

}
