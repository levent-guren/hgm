package hgm.gov.controller;

import javax.inject.Inject;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import hgm.gov.entities.Personel;
import hgm.gov.service.PersonelService;
import hgm.gov.util.Util;

@RestController
@RequestMapping("/personel")
public class PersonelController {
	@Inject
	private PersonelService personelService;

	@GetMapping("/liste")
	public String liste() {
		JsonArray sonuc = new JsonArray();
		personelService.getPersonelListesi().forEach(p -> {
			JsonObject personelJsonObject = new JsonObject();
			personelJsonObject.addProperty("id", p.getId());
			personelJsonObject.addProperty("tcNo", p.getTcno());
			personelJsonObject.addProperty("adi", p.getAdi());
			personelJsonObject.addProperty("soyadi", p.getSoyadi());
			personelJsonObject.addProperty("birlikId", p.getBirlikId());
			personelJsonObject.addProperty("evKoorEnlem", p.getEvKoordinatEnlem());
			personelJsonObject.addProperty("evKoorBoylam", p.getEvKoordinatBoylam());

			sonuc.add(personelJsonObject);
		});

		return sonuc.toString();
	}

	@GetMapping("/detay/{id}")
	public String detay(@PathVariable int id) {
		Personel personel = personelService.getPersonel(id);
		JsonObject personelJsonObject = new JsonObject();
		if (personel != null) {
			personelJsonObject.addProperty("id", personel.getId());
			personelJsonObject.addProperty("adi", personel.getAdi());
			personelJsonObject.addProperty("soyadi", personel.getSoyadi());
			personelJsonObject.addProperty("tcNo", personel.getTcno());
			personelJsonObject.addProperty("birlikId", personel.getBirlikId());
			personelJsonObject.addProperty("evKoorEnlem", personel.getEvKoordinatEnlem());
			personelJsonObject.addProperty("evKoorBoylam", personel.getEvKoordinatBoylam());
		}
		return personelJsonObject.toString();
	}

	@PutMapping("/guncelle/{id}")
	public String guncelle(@RequestBody String data, @PathVariable int id) {
		JsonObject personelJSON = JsonParser.parseString(data).getAsJsonObject();
		Personel personel = new Personel();
		personel.setAdi(personelJSON.get("adi").getAsString());
		personel.setSoyadi(personelJSON.get("soyadi").getAsString());
		personel.setTcno(personelJSON.get("tcNo").getAsString());
		personel.setId(personelJSON.get("id").getAsInt());
		personel.setEvKoordinatEnlem(personelJSON.get("evKoorEnlem").getAsBigDecimal());
		personel.setEvKoordinatBoylam(personelJSON.get("evKoorBoylam").getAsBigDecimal());
		personelService.personelGuncelle(id, personel);
		return Util.cevapBasarili();
	}

	@GetMapping(value = "/resim/{id}", produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] personelResmi(@PathVariable int id) {
		Personel personel = personelService.getPersonel(id);
		if (personel != null) {
			return personel.getResim();
		}
		return null;
	}

}
