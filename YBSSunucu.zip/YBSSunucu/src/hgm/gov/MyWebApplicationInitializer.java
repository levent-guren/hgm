package hgm.gov;

import javax.servlet.MultipartConfigElement;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.slf4j.LoggerFactory;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;

public class MyWebApplicationInitializer implements WebApplicationInitializer {
	Logger logger = (Logger) LoggerFactory.getLogger(MyWebApplicationInitializer.class);

	public void logSetup() {
		Logger logger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
		logger.setLevel(Level.ERROR);
		logger = (Logger) LoggerFactory.getLogger("hgm");
		logger.setLevel(Level.INFO);
	}

	@Override
	public void onStartup(ServletContext container) throws ServletException {
		logSetup();
		AnnotationConfigWebApplicationContext context = new AnnotationConfigWebApplicationContext();
		context.register(SpringWebConfig.class);
		context.setServletContext(container);

		ServletRegistration.Dynamic dispatcher = container.addServlet("dispatcher", new DispatcherServlet(context));
		dispatcher.setLoadOnStartup(1);
		dispatcher.addMapping("/");

		String property = "java.io.tmpdir";

		// Get the temporary directory and print it.
		String tempDir = System.getProperty(property);
		tempDir = tempDir.replace('\\', '/');
		logger.info("OS temporary directory is " + tempDir);
		MultipartConfigElement multipartConfig = new MultipartConfigElement(tempDir);
		dispatcher.setMultipartConfig(multipartConfig);
	}
}