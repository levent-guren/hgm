package hgm.gov.controller;

import java.io.ByteArrayOutputStream;

import javax.inject.Inject;
import javax.sql.DataSource;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimplePdfExporterConfiguration;
import net.sf.jasperreports.export.SimplePdfReportConfiguration;

@RestController
public class RaporController {
	@Inject
	private DataSource dataSource;

	@GetMapping(value = "/rapor", produces = { MediaType.APPLICATION_PDF_VALUE })
	public byte[] raporOlustur() {
		try {
			JasperReport jasperReport = (JasperReport) JRLoader.loadObjectFromFile("c:/java/rapor/Blank_A4.jasper");

			// Rapor dosyas� projenin i�indeyse:
			// InputStream employeeReportStream =
			// getClass().getResourceAsStream("/Blank_A4.jrxml");

			// Rapor dosyas� proje i�inde de�ilse:
			// InputStream employeeReportStream = new
			// FileInputStream("c:/java/rapor/Blank_A4.jrxml");

			// JasperReport jasperReport =
			// JasperCompileManager.compileReport(employeeReportStream);

			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, null, dataSource.getConnection());
			JRPdfExporter exporter = new JRPdfExporter();
			exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
			ByteArrayOutputStream s = new ByteArrayOutputStream();
			exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(s));

			SimplePdfReportConfiguration reportConfig = new SimplePdfReportConfiguration();
			reportConfig.setSizePageToContent(true);
			reportConfig.setForceLineBreakPolicy(false);

			SimplePdfExporterConfiguration exportConfig = new SimplePdfExporterConfiguration();
			exportConfig.setMetadataAuthor("Levent GUREN");
			exportConfig.setEncrypted(true);
			exportConfig.setAllowedPermissionsHint("PRINTING");

			exporter.setConfiguration(reportConfig);
			exporter.setConfiguration(exportConfig);

			exporter.exportReport();
			return s.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
