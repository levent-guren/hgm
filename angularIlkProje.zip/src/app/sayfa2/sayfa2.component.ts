import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sayfa2',
  template: `
   <div [class]="renk">sayfa 2</div><br/>
   <div [class.kirmizi]="hata">mesaj 2</div><br/>
   <div [ngClass]="ayarlar">mesaj 3</div><br/>

  <div [style.color]="stilRenk1" >Stil 1</div>
  <div [ngStyle]="stiller" >Stil 2</div>
   `,
  styles: [`
  .kirmizi {
    color: red;
  }
  .mavi {
    color: blue;
  }
  .koyu {
    font-weight: 700;
  }
  `]
})
export class Sayfa2Component  {
  renk = "mavi";
  hata = true;
  ayarlar = {
    kirmizi: this.hata,
    koyu: this.renk == 'kirmizi'
  };
  stilRenk1 = "cyan";
  stiller = {
    'color': 'purple',
    'font-weight': 700
  }
}
