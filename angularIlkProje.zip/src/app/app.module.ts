import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Sayfa2Component } from './sayfa2/sayfa2.component';
import { Sayfa3Component } from './sayfa3/sayfa3.component';
import { Sayfa4Component } from './sayfa4/sayfa4.component';

@NgModule({
  declarations: [
    AppComponent,
    Sayfa2Component,
    Sayfa3Component,
    Sayfa4Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [Sayfa4Component]
})
export class AppModule { }
