import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sayfa4',
  template: `
   <table class="tablo">
     <tr class="tabloBaslik"><th>Sıra</th><th>Adı</th><th>Sayfa Sayısı</th>
      <th>i</th><th>tek</th><th>cift</th><th>ilk</th><th>son</th>
    </tr>
     <tr [class.tabloTekSatir]="tek"
         [class.tabloCiftSatir]="cift"
         *ngFor="let k of kitaplar;index as i;odd as tek;even as cift;first as ilk;last as son">
      <td>{{i+1}}</td>
      <td [class.ilkKayit]="ilk" [class.sonKayit]="son" >{{k.adi}}</td>
      <td>{{k.sayfaSayisi}}</td>
      <td>{{i}}</td>
      <td>{{tek}}</td>
      <td>{{cift}}</td>
      <td>{{ilk}}</td>
      <td>{{son}}</td>
     </tr>
   </table>
  `,
  styles: [`
    .tabloBaslik {
      font-size: 0.8rem;
    }
    .tablo {
      border: 1px solid black;
    }
    .tabloTekSatir {
      background-color: rgb(220,220,255);
    }
    .tabloCiftSatir {
      background-color: rgb(200,200,255);
    }
    .ilkKayit {
      color: red;
    }
    .sonKayit {
      color: brown;
      font-style: italic;
    }
  `
  ]
})
export class Sayfa4Component implements OnInit {
  public kitaplar: Kitap[] = [];
  constructor() {
  }

  ngOnInit(): void {
    this.kitaplar.push(new Kitap('Metastaz', 1200));
    this.kitaplar.push(new Kitap('Hobbit', 800));
    this.kitaplar.push(new Kitap('Kırmızı', 500));
    this.kitaplar.push(new Kitap('Kürk Mantolu Madonna', 600));
    this.kitaplar.push(new Kitap('Serenad', 900));
    this.kitaplar.push(new Kitap('İki kule', 3100));
  }

}

class Kitap {
  constructor(public adi: string, public sayfaSayisi: number) {
  }
}
