import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sayfa3',
  template: `
    <input type="text" [(ngModel)]="adi" #txtAdi /><br/>
    <input type="button" (click)="btn1Click(txtAdi.value)" value="Dene"/>
    <input type="button" (click)="btn2Click(txtAdi)" value="Dene 2"/><br/>
    <input type="button" (click)="btn3Click($event)" value="Dene 3"/><br/>

  `,
  styles: [
  ]
})
export class Sayfa3Component {
  public adi: string = '';

  public btn1Click(x: string) {
    console.log('Butona basıldı ' + x);
  }
  public btn2Click(x: any) {
    console.log(x);
  }
  public btn3Click(x: MouseEvent) {
    console.log(x, x.button);
  }
}
