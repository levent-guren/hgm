import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `{{title}}<br/>
  {{2+2}}<br/>
  {{title + '...'}}<br/>
  {{ test()}}<br/>
  {{ test2() }}<br/>
  <!-- {{ window.location.href }} böyle yazılamıyor. -->
  <input type="text" id="{{x}}" /><br/>
  <input type="text" [id]="x" /><br/>

  <input type="text" [disabled]="pasif" value="Merhaba" /><br/>
  <input type="text" [value]="yazi1" /><br/>
  <input type="button" value="Yazıyı değiştir" (click)="yaziDegistir()"/><br/>
  {{yazi1}}<br/>
  <input type="text" [(ngModel)]="yazi1" /><br/>

  `,
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title: string = 'ilkProje';
  x = 'adi';
  pasif = false;
  yazi1 = "Nasılsınız";

  test():number {
    return 5;
  }
  test2() {
    return window.location.href;
  }
  yaziDegistir() {
    this.yazi1 = "iyi misiniz?";
  }
}
