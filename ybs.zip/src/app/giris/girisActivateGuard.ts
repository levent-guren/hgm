import { ToastrService } from 'ngx-toastr';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from 'rxjs';
import { GirisService } from '../servis/giris.service';
import { Personel } from '../beans/personel';

@Injectable()
export class GirisActivateGuard implements CanActivate {
  constructor(
    private toastr: ToastrService,
    private girisService: GirisService,
    private router: Router
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    const tcNo = localStorage.getItem("tcNo");
    const sifre = localStorage.getItem("sifre");
    if (tcNo !== null) {
      // önceki girişte beni hatırla işaretli olarak girilmiş.
      this.girisService.girisYap(tcNo, sifre).subscribe(
        s => {
          if (s['sonuc'] === true) {
            // otomatik giriş başarılı oldu.
            this.girisService.girisYapanPersonel = new Personel(0, s['adi'], s['soyadi'], tcNo, s['birlikId'], 0, 0, s['resim']);
            this.toastr.info('Otomatik giriş yapıldı');
            this.router.navigate(['/menu']);
            return false;
          } else {
            // otomatik giriş yapılamadı.
            this.toastr.error('Otomatik olarak giriş yapılamadı');
            localStorage.clear();
            this.girisService.girisYapanPersonel = null;
            this.router.navigate(['/']);
            return false;
          }
        },
        hata => {
          this.toastr.error('Sunucu hatası');
          return true;
        }
      );
    } else {
      return true;
    }
  }
}
