import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { GirisService } from '../servis/giris.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-giris',
  templateUrl: './giris.component.html',
  styleUrls: ['./giris.component.scss']
})
export class GirisComponent implements OnInit {
  girisForm: FormGroup;

  constructor(private fb: FormBuilder, private girisService: GirisService, private toastr: ToastrService,
  private router: Router) { }

  ngOnInit(): void {
    this.girisForm = this.fb.group({
      tcNo: '',
      sifre: '',
      hatirla: false,
    });
  }
  girisYap() {
    let tcNo = this.girisForm.get('tcNo').value;
    let sifre = this.girisForm.get('sifre').value;

    this.girisService.girisYap(tcNo, sifre).subscribe(
      s => {
        if (s['sonuc'] === true) {
          this.toastr.info('Giriş başarılı');
          this.router.navigate(['/menu']);
        } else {
          this.toastr.error('Yanlış T.C. no / şifre girdiniz.');
        }
      },
      e => {
        // hata oluştu
        console.error(e);
      }
    );
  }

}
