import { ToastrService } from 'ngx-toastr';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from 'rxjs';
import { GirisService } from '../servis/giris.service';
import { Personel } from '../beans/personel';

@Injectable()
export class MenuActivateGuard implements CanActivate {
  constructor(
    private toastr: ToastrService,
    private girisService: GirisService,
    private router: Router
  ) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    console.log('MenuActivateGuard');
    // giriş yapılmadıysa menü sayfasının gelmesini engelleyelim.
    if (this.girisService.girisYapanPersonel == null) {
      console.log('personel null');
      // giriş yapılmamıştır. Menü'nün gelmesini engelliyoruz
      if (localStorage.getItem('tcNo') == null) {
        // otomatik giriş yapılamayacak. Hata mesajı vermeliyiz.
        this.toastr.error("Önce giriş yapmalısınız.");
      }
      this.router.navigate(['/']);
      return false;
    } else {
      console.log(this.girisService.girisYapanPersonel);
      return true;
    }
  }
}
