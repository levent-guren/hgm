import { GirisService } from './../servis/giris.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.scss']
})
export class MenuComponent implements OnInit {

  constructor(private girisService: GirisService, private router: Router) { }

  ngOnInit(): void {
  }
  getGirisService():GirisService {
    return this.girisService;
  }
  cikisYap() {
    localStorage.clear();
    this.girisService.girisYapanPersonel = null;
    this.router.navigate(['/']);
  }

}
