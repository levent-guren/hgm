import { MenuActivateGuard } from './menu/menuActivateGuard';
import { GirisActivateGuard } from './giris/girisActivateGuard';
import { RaporListesiComponent } from './rapor/rapor-listesi/rapor-listesi.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GirisComponent } from './giris/giris.component';
import { MenuComponent } from './menu/menu.component';
import { PersonelDetayComponent } from './personel/personel-detay/personel-detay.component';
import { PersonelListeComponent } from './personel/personel-liste/personel-liste.component';

const routes: Routes = [
  { path: '', redirectTo: 'giris', pathMatch: 'full' },
  { path: 'giris', component: GirisComponent, canActivate: [GirisActivateGuard] },
  {
    path: 'menu', component: MenuComponent, canActivate: [MenuActivateGuard], children: [
      { path: 'personelListe', component: PersonelListeComponent },
      { path: 'personelDetay/:id', component: PersonelDetayComponent },
      { path: 'raporListe', component: RaporListesiComponent },
    ]
  },
  { path: '**', redirectTo: 'giris', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
