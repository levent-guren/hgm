import { MenuActivateGuard } from './menu/menuActivateGuard';
import { GirisActivateGuard } from './giris/girisActivateGuard';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ToastrModule } from 'ngx-toastr';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GirisComponent } from './giris/giris.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MenuComponent } from './menu/menu.component';
import { PersonelListeComponent } from './personel/personel-liste/personel-liste.component';
import { PersonelDetayComponent } from './personel/personel-detay/personel-detay.component';
import { icon, Marker } from 'leaflet';
import { RaporOlusturComponent } from './rapor/rapor-olustur/rapor-olustur.component';
import { RaporListesiComponent } from './rapor/rapor-listesi/rapor-listesi.component';

const iconRetinaUrl = 'assets/marker-icon-2x.png';
const iconUrl = 'assets/marker-icon.png';
const shadowUrl = 'assets/marker-shadow.png';
const iconDefault = icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41]
});
Marker.prototype.options.icon = iconDefault;

@NgModule({
  declarations: [
    AppComponent,
    GirisComponent,
    MenuComponent,
    PersonelListeComponent,
    PersonelDetayComponent,
    RaporOlusturComponent,
    RaporListesiComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgbModule,
  ],
  providers: [
    GirisActivateGuard,
    MenuActivateGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
