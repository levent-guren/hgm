import { Personel } from 'src/app/beans/personel';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GirisService {
  public girisYapanPersonel: Personel;
  constructor(private http: HttpClient) { }

  girisYap(tcNo, sifre) {
    const headers = new HttpHeaders().set('Content-Type', 'application/json').set('Cache-Control', 'no-cache');
    return this.http.post("http://localhost:8081/YBSSunucu/giris", { tcNo, sifre }, { headers, withCredentials: true  });
  }
}
