import { Personel } from './../beans/personel';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PersonelService {

  constructor(private http: HttpClient) { }

  personelListesi(): Observable<Personel[]> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json').set('Cache-Control', 'no-cache');
    return this.http.get<Personel[]>("http://localhost:8081/YBSSunucu/personel/liste", { headers });
  }

  personelDetay(id): Observable<Personel> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json').set('Cache-Control', 'no-cache');
    return this.http.get<Personel>("http://localhost:8081/YBSSunucu/personel/detay?id="+id, { headers });
  }
}
