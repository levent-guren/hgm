import { Observable } from 'rxjs';
import { Rapor } from './../beans/rapor';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RaporService {

  constructor(private http: HttpClient) { }

  raporListesi(): Observable<Rapor[]> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json').set('Cache-Control', 'no-cache');
    return this.http.get<Rapor[]>("http://localhost:8081/YBSSunucu/rapor/liste", { headers });
  }

  raporAl(raporAdi: string): Observable<any> {
    const headers = new HttpHeaders().set('Content-Type', 'application/json').set('Cache-Control', 'no-cache');
    return this.http.put<Rapor[]>("http://localhost:8081/YBSSunucu/rapor/olustur", { raporAdi }, { headers });
  }

}
