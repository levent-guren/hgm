import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rapor-olustur',
  templateUrl: './rapor-olustur.component.html',
  styleUrls: ['./rapor-olustur.component.scss']
})
export class RaporOlusturComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
