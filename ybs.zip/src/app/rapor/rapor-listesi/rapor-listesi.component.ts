import { Rapor } from './../../beans/rapor';
import { Component, OnInit } from '@angular/core';
import { RaporService } from 'src/app/servis/rapor.service';

@Component({
  selector: 'app-rapor-listesi',
  templateUrl: './rapor-listesi.component.html',
  styleUrls: ['./rapor-listesi.component.scss']
})
export class RaporListesiComponent implements OnInit {
  raporlar: Rapor[] = [];

  constructor(private raporServis: RaporService) { }

  ngOnInit(): void {
    this.raporServis.raporListesi().subscribe(
      raporlar => {
        this.raporlar = raporlar;
      },
      hata => {

      }
    );
  }

}
