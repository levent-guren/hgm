export class Rapor {
  constructor(public id: number, public adi: string, private tarih: Date, private personelId: number) { }
}
