export class Personel {
  constructor(public id: number, public adi: string, public soyadi: string,
    public tcNo: string, public birlikId: number,
    public evKoorEnlem: number, public evKoorBoylam: number,
    public resim: string
  ) { }
}
