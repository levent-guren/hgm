import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelService } from 'src/app/servis/personel.service';

@Component({
  selector: 'app-personel-liste',
  templateUrl: './personel-liste.component.html',
  styleUrls: ['./personel-liste.component.scss']
})
export class PersonelListeComponent implements OnInit {
  personelListe: Personel[] = [];
  constructor(private personelService: PersonelService, private router: Router) { }

  ngOnInit(): void {
    this.personelService.personelListesi().subscribe(
      sonuc => {
        console.log(sonuc);
        this.personelListe = sonuc;
      },
      e => console.log(e)
    );
  }
  personelDetay(id) {
    this.router.navigate(['/menu/personelDetay', id]);
  }

}
