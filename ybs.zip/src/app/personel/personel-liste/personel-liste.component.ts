import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelService } from 'src/app/servis/personel.service';
import { Marker, Map } from 'leaflet';
import * as L from 'leaflet';


@Component({
  selector: 'app-personel-liste',
  templateUrl: './personel-liste.component.html',
  styleUrls: ['./personel-liste.component.scss']
})
export class PersonelListeComponent implements OnInit, AfterViewInit {
  private map: Map;
  personelListe: Personel[] = [];

  constructor(private personelService: PersonelService, private router: Router) { }

  ngOnInit(): void {
    this.personelService.personelListesi().subscribe(
      sonuc => {
        this.personelListe = sonuc;
        this.personelListe.forEach(
          p => {
            if (p.evKoorBoylam !== null) {
              L.marker([p.evKoorEnlem, p.evKoorBoylam]).addTo(this.map).update();
            }
          }
        );
      },
      e => console.log(e)
    );
  }

  ngAfterViewInit(): void {
    this.initMap();
  }

  private initMap(): void {
    this.map = L.map('map2', {
      center: [39.932588915042636, 32.88204979657022],
      zoom: 17
    });

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      minZoom: 3
    });
    tiles.addTo(this.map);
  }

  personelDetay(id) {
    this.router.navigate(['/menu/personelDetay', id]);
  }

}
