import { AfterViewInit, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelService } from 'src/app/servis/personel.service';
import { Marker, Map } from 'leaflet';
import * as L from 'leaflet';
import { RaporService } from 'src/app/servis/rapor.service';

@Component({
  selector: 'app-personel-liste',
  templateUrl: './personel-liste.component.html',
  styleUrls: ['./personel-liste.component.scss']
})
export class PersonelListeComponent implements OnInit, AfterViewInit {
  private map: Map;
  personelListe: Personel[] = [];
  private cache: number;

  constructor(private personelService: PersonelService, private router: Router, private raporServis: RaporService) { }

  ngOnInit(): void {
    this.personelService.personelListesi().subscribe(
      sonuc => {
        this.personelListe = sonuc;
        this.personelListe.forEach(
          p => {
            if (p.evKoorBoylam !== null) {
              var personelIcon = L.icon({
                iconUrl: this.getResimUrl(p),
                iconSize: [100,100], // size of the icon
                shadowSize: [0, 0], // size of the shadow
                iconAnchor: [22, 94], // point of the icon which will correspond to marker's location
                shadowAnchor: [4, 62],  // the same for the shadow
                popupAnchor: [-3, -76] // point from which the popup should open relative to the iconAnchor
              });

              let marker = L.marker([p.evKoorEnlem, p.evKoorBoylam], { icon: personelIcon });
              marker.bindPopup("T.C. No:<b>" + p.tcNo + "</b><br/>Adı:" + p.adi + "<br/>Soyadı:" + p.soyadi);
              marker.addTo(this.map).update();
            }
          }
        );
      },
      e => console.log(e)
    );
  }

  getResimUrl(personel) {
    return "http://localhost:8081/YBSSunucu/personel/resim/" + personel.id + "?t=" + this.getCache();
  }
  getCache() {
    if (this.cache === null) {
      this.cache = new Date().getTime();
    }
    return this.cache;
  }

  ngAfterViewInit(): void {
    this.initMap();
  }

  private initMap(): void {
    this.map = L.map('map2', {
      center: [39.932588915042636, 32.88204979657022],
      zoom: 17
    });

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      minZoom: 3
    });
    tiles.addTo(this.map);
  }

  personelDetay(id) {
    this.router.navigate(['/menu/personelDetay', id]);
  }
  raporAl() {
    this.raporServis.raporAl('personelListesi').subscribe(
      sonuc => {
        this.router.navigate(['/menu/raporListe']);
      }
    );
  }

}
