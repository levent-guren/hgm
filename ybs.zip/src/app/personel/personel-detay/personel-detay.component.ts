import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelService } from 'src/app/servis/personel.service';
import { icon, Marker } from 'leaflet';
import * as L from 'leaflet';

const iconRetinaUrl = 'assets/marker-icon-2x.png';
const iconUrl = 'assets/marker-icon.png';
const shadowUrl = 'assets/marker-shadow.png';
const iconDefault = icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41]
});
Marker.prototype.options.icon = iconDefault;

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss']
})
export class PersonelDetayComponent implements OnInit, AfterViewInit {
  private map;
  personel: Personel;
  personelForm: FormGroup;
  evMarker;

  constructor(private activatedRoute: ActivatedRoute, private personelService: PersonelService, private fb: FormBuilder) { }

  ngAfterViewInit(): void {
    this.initMap();
  }

  private initMap(): void {
    this.map = L.map('map', {
      center: [39.932588915042636, 32.88204979657022],
      zoom: 17
    });

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      minZoom: 3
    });

    tiles.addTo(this.map);
    this.map.on('click', (e) => {
      this.haritaTiklandi(e);
    })
  }

  haritaTiklandi(e) {
    if (this.evMarker == null) {
      // ilk defa tıklanıyor. İlk yerini belirle ve haritaya ekle
      this.evMarker = L.marker([e.latlng.lat, e.latlng.lng]);
      this.evMarker.addTo(this.map);
    } else {
      // yerini değiştir
      var newLatLng = new L.LatLng(e.latlng.lat, e.latlng.lng);
      this.evMarker.setLatLng(newLatLng);
      this.evMarker.update();
    }
  }
  ngOnInit(): void {
    this.personelForm = this.fb.group({
      adi: '',
      soyadi: '',
      tcNo: ''
    })

    this.activatedRoute.paramMap.subscribe(
      parametreler => {
        let id = parametreler.get('id');
        this.personelService.personelDetay(id).subscribe(
          p => {
            this.personel = p;
            this.personelForm.setValue({adi: p.adi, soyadi: p.soyadi, tcNo: p.tcNo});
          }
        );
      }
    );
  }

}
