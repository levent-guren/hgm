import { ToastrService } from 'ngx-toastr';
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelService } from 'src/app/servis/personel.service';
import {  Marker, Map} from 'leaflet';
import * as L from 'leaflet';

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss']
})
export class PersonelDetayComponent implements OnInit, AfterViewInit {
  private map: Map;
  personel: Personel;
  personelForm: FormGroup;
  evMarker: Marker;

  constructor(private activatedRoute: ActivatedRoute, private personelService: PersonelService, private fb: FormBuilder,
    private toastr: ToastrService, private router: Router) { }

  ngAfterViewInit(): void {
    this.initMap();
  }

  private initMap(): void {
    this.map = L.map('map', {
      center: [39.932588915042636, 32.88204979657022],
      zoom: 17
    });

    const tiles = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 18,
      minZoom: 3
    });

    tiles.addTo(this.map);
    this.map.on('click', (e) => {
      this.haritaTiklandi(e);
    })
  }

  haritaTiklandi(e) {
    if (this.evMarker == null) {
      // ilk defa tıklanıyor. İlk yerini belirle ve haritaya ekle
      this.evMarker = L.marker([e.latlng.lat, e.latlng.lng]);
      this.evMarker.addTo(this.map);
    } else {
      // yerini değiştir
      var newLatLng = new L.LatLng(e.latlng.lat, e.latlng.lng);
      this.evMarker.setLatLng(newLatLng);
      this.evMarker.update();
    }
  }
  ngOnInit(): void {
    this.personelForm = this.fb.group({
      adi: '',
      soyadi: '',
      tcNo: ''
    })

    this.activatedRoute.paramMap.subscribe(
      parametreler => {
        let id = parametreler.get('id');
        this.personelService.personelDetay(id).subscribe(
          p => {
            this.personel = p;
            this.personelForm.setValue({ adi: p.adi, soyadi: p.soyadi, tcNo: p.tcNo });
            if (p.evKoorBoylam !== null) {
              // enlem boylam bilgisi bulunuyor.
              this.evMarker = L.marker([p.evKoorEnlem, p.evKoorBoylam]);
              this.evMarker.addTo(this.map);
            }
          }
        );
      }
    );
  }
  guncelle(): void {
   // console.log(this.personelForm.get('resim'));
   // console.log(this.personelForm.get('resim').value);
    //return;
    this.personel.adi = this.personelForm.get('adi').value;
    this.personel.soyadi = this.personelForm.get('soyadi').value;
    this.personel.tcNo = this.personelForm.get('tcNo').value;
    if (this.evMarker !== null) {
      this.personel.evKoorEnlem = this.evMarker._latlng.lat;
      this.personel.evKoorBoylam = this.evMarker._latlng.lng;
    }
    this.personelService.personelGuncelle(this.personel).subscribe(
      s => {
        if (s['sonuc'] === 'basarili') {
          this.toastr.info("Personel güncellendi");
          this.router.navigate(['/menu/personelListe']);
        }
      }
    );
  }
}
