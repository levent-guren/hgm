import { Component, OnInit } from '@angular/core';
import { Personel } from '../beans/personel';
import { PersonelService } from '../servis/personel.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit {
  personeller: Personel[] = [];
  constructor(private personelServis: PersonelService) { }
  ngOnInit() {
    this.personelServis.getPersoneller().subscribe(
      liste => {
        this.personeller = liste;
      },
      hata => {
        console.log(hata);
      }
    );
  }
}
