package hgm.gov.service;

import java.util.List;
import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;

import hgm.gov.beans.Personel;
import hgm.gov.dao.PersonelDAO;

@Named
public class PersonelService {
	@Inject
	private PersonelDAO personelDAO;

	public List<Personel> getPersoneller() {
		return personelDAO.getPersoneller();
	}

	public Personel getPersonel(int id) {
		Optional<Personel> o = personelDAO.getPersonel(id);
		if (o.isPresent()) {
			return o.get();
		}
		return null;
	}
}
