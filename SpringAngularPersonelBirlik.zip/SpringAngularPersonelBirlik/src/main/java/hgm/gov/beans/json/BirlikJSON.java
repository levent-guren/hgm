package hgm.gov.beans.json;

import lombok.Data;

@Data
public class BirlikJSON {
	private Integer id;
	private String adi;
}
