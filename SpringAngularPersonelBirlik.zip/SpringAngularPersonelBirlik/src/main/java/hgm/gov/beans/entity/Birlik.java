package hgm.gov.beans.entity;

import java.util.Set;

import javax.inject.Named;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Named
@Entity
public class Birlik {
	@Id
	private int id;
	private String adi;
	private int mevcut;
	private String sehir;
	@ToString.Exclude
	@OneToMany(mappedBy = "birlik")
	private Set<Personel> personel;
}
