package hgm.gov.beans.json;

import lombok.Data;

@Data
public class PersonelJSON {
	private Integer id;
	private String adi;
	private String soyadi;
	private String tcno;
	private String sifre;
	private String resim;
	private String birlikId;
}
