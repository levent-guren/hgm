package hgm.gov.beans.json;

import lombok.Data;

@Data
public class PersonelJSON {
	private String adi;
	private String soyadi;
	private String tcno;
	private String sifre;
}
