package hgm.gov.beans.json;

import lombok.Data;

@Data
public class PersonelJSON {
	private int id;
	private String adi;
	private String soyadi;
	private String tcno;
	private String sifre;
	private String resim;
}
