package hgm.gov.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import hgm.gov.beans.entity.Birlik;

public interface BirlikRepository extends JpaRepository<Birlik, Integer> {

}
