package hgm.gov.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;

import org.modelmapper.ModelMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import hgm.gov.beans.entity.Birlik;
import hgm.gov.beans.json.BirlikJSON;
import hgm.gov.service.BirlikService;

@RestController
public class BirlikController {
	@Inject
	private BirlikService birlikService;
	@Inject
	private ModelMapper modelMapper;

	@GetMapping("/birlik")
	public List<BirlikJSON> getBirlikler() {
		return birlikService.getBirlikler().stream().map(this::convertTo).collect(Collectors.toList());
	}

	private BirlikJSON convertTo(Birlik birlik) {
		return modelMapper.map(birlik, BirlikJSON.class);
	}

}
