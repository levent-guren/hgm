package hgm.gov.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import hgm.gov.beans.entity.Personel;
import hgm.gov.beans.json.PersonelJSON;
import hgm.gov.service.PersonelService;
import hgm.gov.util.Util;

@RestController
public class PersonelController {
	@Inject
	private PersonelService personelService;

	@GetMapping("/personel")
	public List<Personel> getPersoneller() {
		return personelService.getPersoneller();
	}

	@GetMapping("/personel/{id}")
	public Personel getPersonel(@PathVariable("id") int id) {
		return personelService.getPersonel(id);
	}

	@PostMapping("/personel")
	public String personelYarat(@RequestBody PersonelJSON personelJson) {
		Personel personel = new Personel();
		personel.setAdi(personelJson.getAdi());
		personel.setSoyadi(personelJson.getSoyadi());
		personel.setSifre(personelJson.getSifre());
		personel.setTcno(personelJson.getTcno());

		Personel olusturulanPersonel = personelService.personelOlustur(personel);
		return Util.tamamCevabiOlustur("personelId", olusturulanPersonel.getId());
	}
}
