package hgm.gov.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import hgm.gov.beans.Personel;
import hgm.gov.service.PersonelService;

@RestController
public class PersonelController {
	@Inject
	private PersonelService personelService;

	@GetMapping("/personel")
	public List<Personel> getPersoneller() {
		return personelService.getPersoneller();
	}

	@GetMapping("/personel/{id}")
	public Personel getPersonel(@PathVariable("id") int id) {
		return personelService.getPersonel(id);
	}
}
