package hgm.gov;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LogAspect {
	@Before("execution (* hgm.gov.repository.*.*(..))")
	public void loglama(JoinPoint joinPoint) {
		System.out.println("Loglama çağırıldı.");
	}
}
