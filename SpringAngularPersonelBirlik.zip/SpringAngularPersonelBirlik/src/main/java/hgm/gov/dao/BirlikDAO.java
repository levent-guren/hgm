package hgm.gov.dao;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import hgm.gov.beans.entity.Birlik;
import hgm.gov.repository.BirlikRepository;

@Named
public class BirlikDAO {
	@Inject
	private BirlikRepository birlikRepository;

	public List<Birlik> getBirlikler() {
		return birlikRepository.findAll();
	}

}
