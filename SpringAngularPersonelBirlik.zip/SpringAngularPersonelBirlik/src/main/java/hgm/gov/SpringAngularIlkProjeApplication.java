package hgm.gov;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAngularIlkProjeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAngularIlkProjeApplication.class, args);
	}

}
