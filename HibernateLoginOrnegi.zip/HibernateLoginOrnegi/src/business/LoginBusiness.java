package business;

public class LoginBusiness {

	public LoginBusiness() {
		// TODO Auto-generated constructor stub
	}

}
