export class Personel {
  constructor(public id: number, public tcno: string, public adi: string, public soyadi: string,
              public sifre: string, public birlik_id: number, public resim: string) { }
}
