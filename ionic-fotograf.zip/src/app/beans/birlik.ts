export class Birlik {
  constructor(public id: number, public adi: string) { }
}
