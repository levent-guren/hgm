import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { PersonelDetayComponent } from './personel-detay/personel-detay.component';
import { PersonelListesiComponent } from './personel-listesi/personel-listesi.component';

const routes: Routes = [
  { path: '', redirectTo: 'personelListesi', pathMatch: 'full' },
  { path: 'personelListesi', component: PersonelListesiComponent },
  { path:'personelListesiDetay/:id', component: PersonelDetayComponent },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
