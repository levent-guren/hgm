import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Personel } from '../beans/personel';
import { PersonelService } from '../service/personel.service';

@Component({
  selector: 'app-personel-listesi',
  templateUrl: './personel-listesi.component.html',
  styleUrls: ['./personel-listesi.component.scss'],
})
export class PersonelListesiComponent implements OnInit {
  personeller: Personel[];

  constructor(private personelService: PersonelService, private router: Router) { }

  ngOnInit() {
  }

  personelDetayaGit(id: number) {
    this.router.navigate(['/personelListesiDetay', id]);
  }

  // sayfaya her girdiğimizde ngOnInit çalıştırılmadığından listenin güncellenmesi için
  // yazıldı
  ionViewDidEnter() {
    this.personelService.getPersoneller().subscribe(p => this.personeller = p);
  }
}
