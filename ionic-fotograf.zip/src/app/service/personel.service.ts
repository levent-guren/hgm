import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Personel } from '../beans/personel';

@Injectable({
  providedIn: 'root'
})
export class PersonelService {
  constructor(private http: HttpClient) { }

  getPersoneller(): Observable<Personel[]> {
    return this.http.get<Personel[]>('http://192.168.2.6:23000/personel');
  }

  getPersonelDetay(personelId: number): Observable<Personel> {
    return this.http.get<Personel>('http://192.168.2.6:23000/personel/' + personelId);
  }
}
