import { Birlik } from './../beans/birlik';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Personel } from '../beans/personel';

@Injectable({
  providedIn: 'root'
})
export class BirlikService {
  constructor(private http: HttpClient) { }

  getBirlikler(): Observable<Birlik[]> {
    return this.http.get<Birlik[]>('http://192.168.2.6:23000/birlik');
  }

}
