import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Personel } from '../beans/personel';
import { PersonelService } from '../service/personel.service';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss'],
})
export class PersonelDetayComponent implements OnInit {
  personel: Personel;
  constructor(private route: ActivatedRoute, private personelService: PersonelService, private camera: Camera) { }

  cameraOptions: CameraOptions = {
    quality: 100,
    correctOrientation: true,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
  };

  ngOnInit() {
    this.route.paramMap.subscribe(param => {
      let personelId = Number.parseInt(param.get('id'));
      this.personelService.getPersonelDetay(personelId).subscribe(
        data => this.personel= data
      );
    });
  }
  fotografCek() {
    this.camera.getPicture(this.cameraOptions).then(
      resimBilgisi => {
        // resimBilgisi Base64 formatında geliyor.
        this.personel.resim = resimBilgisi;
      }
    );
  }
}
