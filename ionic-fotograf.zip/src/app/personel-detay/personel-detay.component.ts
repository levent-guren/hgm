import { Birlik } from './../beans/birlik';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Personel } from '../beans/personel';
import { PersonelService } from '../service/personel.service';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import { FormBuilder, FormGroup } from '@angular/forms';
import { BirlikService } from '../service/birlik.service';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss'],
})
export class PersonelDetayComponent implements OnInit {
  personelForm: FormGroup;
  resimVerisi;
  personelId: number;
  birlikler: Birlik[] = [];

  customActionSheetOptions: any = {
    header: 'Colors',
    subHeader: 'Select your favorite color'
  };

  constructor(private route: ActivatedRoute, private personelService: PersonelService,
    private camera: Camera, private formBuilder: FormBuilder, private router: Router,
    private birlikService: BirlikService, private toast: ToastController) { }


  cameraOptions: CameraOptions = {
    quality: 100,
    correctOrientation: true,
    targetWidth: 200,
    targetHeight:200,
    destinationType: this.camera.DestinationType.DATA_URL,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
  };

  ngOnInit() {
    this.route.paramMap.subscribe(param => {
      let personelId: number = Number.parseInt(param.get('id'));
      this.personelId = personelId;
      this.personelService.getPersonelDetay(personelId).subscribe(
        data => {
          this.personelForm.get('adi').setValue(data.adi);
          this.personelForm.get('soyadi').setValue(data.soyadi);
          this.personelForm.get('tcno').setValue(data.tcno);
          this.personelForm.get('birlik').setValue(data.birlikId);
          this.resimVerisi = data.resim;
        }
      );
    });
    this.personelForm = this.formBuilder.group({
      adi: '',
      soyadi: '',
      tcno: '',
      sifre: '',
      birlik: ''
    });
    this.birlikService.getBirlikler().subscribe(
      data => this.birlikler = data
    );
  }
  fotografCek() {
    this.camera.getPicture(this.cameraOptions).then(
      resimBilgisi => {
        // resimBilgisi Base64 formatında geliyor.
        this.resimVerisi = resimBilgisi;
      }
    );
  }
  guncelle() {
    let personel: Personel = new Personel(
      this.personelId,
      this.personelForm.get('tcno').value,
      this.personelForm.get('adi').value,
      this.personelForm.get('soyadi').value,
      this.personelForm.get('sifre').value,
      this.personelForm.get('birlik').value,
      this.resimVerisi,
    );
    this.personelService.personelGuncelle(personel).subscribe(
      data => {
        // kayıt başarılı
        this.router.navigate(['/']);
        this.toast.create({ message: 'Personel Güncellenmiştir', duration: 2000 }).then(
          a => a.present()
        );
      },
      hata => {
        // hata oluştu
        this.toast.create({ message: 'Hata oluştu', duration: 2000 }).then(
          a => a.present()
        );
      }

    );
  }
}
