import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { KitapComponent } from './kitap/kitap.component';
import { MenuComponent } from './menu/menu.component';
import { PersonelComponent } from './personel/personel.component';

const routes: Routes = [
  { path: '', redirectTo: 'menu', pathMatch: 'full' },
  { path: 'menu', component: MenuComponent },
  { path: 'personel', component: PersonelComponent },
  { path: 'kitap', component: KitapComponent },
  { path: '**', redirectTo: 'kitap', pathMatch: 'prefix'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
