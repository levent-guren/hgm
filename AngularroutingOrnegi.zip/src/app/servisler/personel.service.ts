import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IPersonel } from './ipersonel';

@Injectable({
  providedIn: 'root'
})
export class PersonelService {
  constructor(private http: HttpClient) { }

  public getPersoneller(): Observable<IPersonel[]> {
    return this.http.get<IPersonel[]>('http://localhost:4200/assets/personeller.json');
  }

}
