export interface IPersonel {
  adi: string;
  soyadi: string;
}
