import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pkitap',
  templateUrl: './kitap.component.html',
  styleUrls: ['./kitap.component.scss']
})
export class KitapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
