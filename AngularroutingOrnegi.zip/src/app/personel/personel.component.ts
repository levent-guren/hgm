import { Component, OnInit } from '@angular/core';
import { IPersonel } from '../servisler/ipersonel';
import { PersonelService } from '../servisler/personel.service';

@Component({
  selector: 'app-personel',
  templateUrl: './personel.component.html',
  styleUrls: ['./personel.component.scss']
})
export class PersonelComponent implements OnInit {
  private personeller: IPersonel[] = [];

  constructor(private personelServis: PersonelService) {}

  ngOnInit(): void {
    this.personelServis.getPersoneller().subscribe(sonuc => this.personeller = sonuc );
  }

  getPersoneller(): IPersonel[] {
    return this.personeller;
  }

}
