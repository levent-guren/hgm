import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MenuComponent } from './menu/menu.component';
import { PersonelListesiComponent } from './personel-listesi/personel-listesi.component';
import { SayfaBulunamadiComponent } from './sayfa-bulunamadi/sayfa-bulunamadi.component';

const routes: Routes = [
  { path: '', redirectTo: 'menu', pathMatch: 'full' },
  { path: 'menu', component: MenuComponent },
  { path: 'personelListe', component: PersonelListesiComponent },
  { path: '**', component: SayfaBulunamadiComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
