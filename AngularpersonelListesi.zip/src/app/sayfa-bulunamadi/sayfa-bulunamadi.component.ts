import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sayfa-bulunamadi',
  templateUrl: './sayfa-bulunamadi.component.html',
  styleUrls: ['./sayfa-bulunamadi.component.scss']
})
export class SayfaBulunamadiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
