import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Inject, Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable()
export class BaseInterceptor implements HttpInterceptor {
  constructor(@Inject('BASE_API_URL') private BASE_URL: string) {}
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let url = this.BASE_URL + req.url;
    let myRequest = req.clone({ url });
    return next.handle(myRequest);
  }
}
