import { Component, OnInit } from '@angular/core';
import { Personel } from '../beans/personel';
import { PersonelService } from '../service/personel.service';

@Component({
  selector: 'app-personel-listesi',
  templateUrl: './personel-listesi.component.html',
  styleUrls: ['./personel-listesi.component.scss']
})
export class PersonelListesiComponent implements OnInit {
  private personeller: Personel[] = [];

  constructor(private personelService: PersonelService) { }

  ngOnInit(): void {
    this.personelService.getPersoneller().subscribe(data => this.personeller = data);
  }
  getPersonelListesi() {
    return this.personeller;
  }
}
