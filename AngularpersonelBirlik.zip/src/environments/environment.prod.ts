export const environment = {
  production: true,
  apiURL: 'http://localhost:23000'
};
