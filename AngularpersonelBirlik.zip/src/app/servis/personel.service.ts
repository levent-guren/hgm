import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Personel } from '../beans/personel';

@Injectable({
  providedIn: 'root'
})
export class PersonelServis {

  constructor(private http: HttpClient) { }

  public getPersonelListesi(): Observable<Personel[]> {
    return this.http.get<Personel[]>('/personel');
  }
  public getPersonelDetay(personelId: number): Observable<Personel> {
    return this.http.get<Personel>('/personel/'+personelId);
  }
  public personelKaydet(personel: Personel): Observable<any> {
    console.log(personel);
    return this.http.post<any>('/personel', personel);
  }

}
