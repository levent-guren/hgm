import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BirlikAnasayfaComponent } from './birlik/birlik-anasayfa/birlik-anasayfa.component';
import { PersonelAnasayfaComponent } from './personel/personel-anasayfa/personel-anasayfa.component';
import { PersonelDetayComponent } from './personel/personel-detay/personel-detay.component';
import { PersonelEkleComponent } from './personel/personel-ekle/personel-ekle.component';
import { PersonelListeComponent } from './personel/personel-liste/personel-liste.component';

const routes: Routes = [
  //{ path: '', redirectTo: 'personel', pathMatch: 'full' },
  {
    path: 'personel', component: PersonelAnasayfaComponent, children: [
      { path: 'personelEkle', component: PersonelEkleComponent },
      { path: 'personelListele', component: PersonelListeComponent },
      { path: 'personelDetay', component: PersonelDetayComponent },
  ]},
  { path: 'birlik', component: BirlikAnasayfaComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
