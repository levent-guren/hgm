import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birlik-ekle',
  templateUrl: './birlik-ekle.component.html',
  styleUrls: ['./birlik-ekle.component.scss']
})
export class BirlikEkleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
