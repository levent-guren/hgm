import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birlik-liste',
  templateUrl: './birlik-liste.component.html',
  styleUrls: ['./birlik-liste.component.scss']
})
export class BirlikListeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
