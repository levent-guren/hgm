import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-birlik-anasayfa',
  templateUrl: './birlik-anasayfa.component.html',
  styleUrls: ['./birlik-anasayfa.component.scss']
})
export class BirlikAnasayfaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
