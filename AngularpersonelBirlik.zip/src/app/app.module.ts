import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PersonelAnasayfaComponent } from './personel/personel-anasayfa/personel-anasayfa.component';
import { PersonelEkleComponent } from './personel/personel-ekle/personel-ekle.component';
import { PersonelListeComponent } from './personel/personel-liste/personel-liste.component';
import { BirlikAnasayfaComponent } from './birlik/birlik-anasayfa/birlik-anasayfa.component';
import { BirlikEkleComponent } from './birlik/birlik-ekle/birlik-ekle.component';
import { BirlikListeComponent } from './birlik/birlik-liste/birlik-liste.component';
import { environment } from 'src/environments/environment';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BaseInterceptor } from './base-interceptor';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PersonelDetayComponent } from './personel/personel-detay/personel-detay.component';

import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';

@NgModule({
  declarations: [
    AppComponent,
    PersonelAnasayfaComponent,
    PersonelEkleComponent,
    PersonelListeComponent,
    BirlikAnasayfaComponent,
    BirlikEkleComponent,
    BirlikListeComponent,
    PersonelDetayComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RippleModule,
    ToastModule,
    InputTextModule,
    ButtonModule
  ],
  providers: [
    MessageService,
    { provide: "BASE_API_URL", useValue: environment.apiURL },
    { provide: HTTP_INTERCEPTORS, useClass: BaseInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
