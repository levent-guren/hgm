import { Component, Inject, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelServis } from 'src/app/servis/personel.service';

@Component({
  selector: 'app-personel-liste',
  templateUrl: './personel-liste.component.html',
  styleUrls: ['./personel-liste.component.scss']
})
export class PersonelListeComponent implements OnInit {
  personelListesi: Personel[] = [];

  constructor(private personelServis: PersonelServis, private router: Router) {}

  ngOnInit(): void {
    this.personelServis.getPersonelListesi().subscribe(liste => this.personelListesi = liste);
  }
  detayaGit(id:number) {
    this.router.navigate(['/personel/personelDetay', { id }]);
  }

}
