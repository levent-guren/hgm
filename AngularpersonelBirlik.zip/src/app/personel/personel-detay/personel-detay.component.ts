import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelServis } from 'src/app/servis/personel.service';

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss']
})
export class PersonelDetayComponent implements OnInit {
  personel: Personel;

  constructor(private personelServis: PersonelServis, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(p => {
      let id: number = Number.parseInt(p.get('id'));
      this.personelServis.getPersonelDetay(id).subscribe(p => this.personel = p);
    });

    //console.log('ngOnInit');
    //this.route.paramMap.subscribe(this.parametreDegisti);
  }
  parametreDegisti(parametreler) {
    console.log('parametreDegisti');
    let id: number = Number.parseInt(parametreler.get('id'));
    if (this.personelServis) this.personelServis.getPersonelDetay(id).subscribe(this.personelBilgisiGeldi);
  }
  personelBilgisiGeldi(p) {
    console.log('personelBilgisiGeldi');
    this.personel = p;
  }

}
