import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Personel } from 'src/app/beans/personel';
import { PersonelServis } from 'src/app/servis/personel.service';

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss']
})
export class PersonelDetayComponent implements OnInit {
  personel: Personel;

  constructor(private personelServis: PersonelServis, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(p => {
      let id: number = Number.parseInt(p.get('id'));
      this.personelServis.getPersonelDetay(id).subscribe(p => this.personel = p);
    });
  }

}
