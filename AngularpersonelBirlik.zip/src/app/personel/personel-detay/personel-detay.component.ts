import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { Personel } from 'src/app/beans/personel';
import { PersonelServis } from 'src/app/servis/personel.service';

@Component({
  selector: 'app-personel-detay',
  templateUrl: './personel-detay.component.html',
  styleUrls: ['./personel-detay.component.scss']
})
export class PersonelDetayComponent implements OnInit {
  personel: Personel;

  constructor(private personelServis: PersonelServis, private route: ActivatedRoute,
              private router: Router, private messageService: MessageService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(p => {
      let id: number = Number.parseInt(p.get('id'));
      this.personelOku(id);
    });
    //let id: number = Number.parseInt(this.route.snapshot.paramMap.get('id'));
    //this.personelOku(id);
  }
  personelOku(id: number) {
    this.personelServis.getPersonelDetay(id).subscribe(
      p => {
        this.personel = p;
      },
      hata => {
        this.messageService.add({ severity: 'error', summary: 'Hata oluştu', detail: hata.error.message});
      }
    );
  }
  parametreDegisti(parametreler) {
    console.log('parametreDegisti');
    let id: number = Number.parseInt(parametreler.get('id'));
    if (this.personelServis) this.personelServis.getPersonelDetay(id).subscribe(this.personelBilgisiGeldi);
  }
  personelBilgisiGeldi(p) {
    console.log('personelBilgisiGeldi');
    this.personel = p;
  }
  oncekiPersonel() {
    let id = this.personel.id - 1;
    this.router.navigate(['/personel/personelDetay', id]);
  }
  sonrakiPersonel() {
    let id = this.personel.id + 1;
    this.router.navigate(['/personel/personelDetay', id]);
  }
}
