import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personel-anasayfa',
  templateUrl: './personel-anasayfa.component.html',
  styleUrls: ['./personel-anasayfa.component.scss']
})
export class PersonelAnasayfaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
