import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { PersonelServis } from 'src/app/servis/personel.service';

@Component({
  selector: 'app-personel-ekle',
  templateUrl: './personel-ekle.component.html',
  styleUrls: ['./personel-ekle.component.scss']
})
export class PersonelEkleComponent implements OnInit {
  public form: FormGroup;
  constructor(private fb: FormBuilder, private personelServis: PersonelServis, private messageService: MessageService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.form = this.fb.group({
      tcno : '',
      adi: '',
      soyadi: '',
      sifre: '',
    });
  }
  personelOlustur() {
    this.personelServis.personelKaydet(this.form.value).subscribe(
      sonuc => {
        this.messageService.add({ severity: 'info', summary: 'İşlem başarılı', detail: 'Personel yaratıldı' });
        this.router.navigate(['/personel/personelListele']);
      }
    );
  }

}
