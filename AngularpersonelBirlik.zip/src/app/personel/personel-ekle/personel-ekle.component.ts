import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personel-ekle',
  templateUrl: './personel-ekle.component.html',
  styleUrls: ['./personel-ekle.component.scss']
})
export class PersonelEkleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
