export class Personel {
  constructor(public id: number, public adi:string, public soyadi:string) { }
}
