package hgm.gov.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import hgm.gov.entities.Isimler;

public interface IsimlerRepository extends JpaRepository<Isimler, Integer> {

}
