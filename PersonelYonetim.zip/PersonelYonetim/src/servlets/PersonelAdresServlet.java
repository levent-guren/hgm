package servlets;

import java.io.IOException;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import beans.Personel;
import beans.PersonelAdres;
import business.PersonelAdresBusiness;

@WebServlet("/personelAdres")
public class PersonelAdresServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int personelId = Integer.parseInt(request.getParameter("id"));
		request.setAttribute("liste", new PersonelAdresBusiness().getPersonelAdresler(personelId));
		request.getRequestDispatcher("/WEB-INF/personelAdresListesi.jsp").forward(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("ISO-8859-9");
		int personelId = Integer.parseInt(req.getParameter("id"));
		PersonelAdres adres = new PersonelAdres();
		adres.setAdres(req.getParameter("adres"));
		Personel personel = new Personel();
		personel.setId(personelId);
		adres.setPersonel(personel);
		new PersonelAdresBusiness().personelAdresEkle(adres);
		req.setAttribute("mesaj", "Personel adresi eklenmi�tir");
		doGet(req, resp);
	}

	@Override
	protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String body = req.getReader().lines().collect(Collectors.joining());
		JSONObject json = new JSONObject(body);

		new PersonelAdresBusiness().personelAdresSil(json.getInt("adresId"));

		resp.getWriter().print("{ \"sonuc\": \"ok\" }");
	}
}
